title: deploy.sh

This is the script that deploys the automatically generated
[FORD](https://github.com/cmacmackin/FORD) documentation which you are
currently reading.

```bash
{!deploy.sh!}
```
