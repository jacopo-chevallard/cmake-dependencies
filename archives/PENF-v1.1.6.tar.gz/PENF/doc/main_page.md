project: PENF
project_dir: ./src/
output_dir: ./doc/html/publish/
project_github: https://github.com/szaghi/PENF
summary: PENF, Portability Environment for Fortran poor people
author: Stefano Zaghi
github: https://github.com/szaghi
email: stefano.zaghi@gmail.com
md_extensions: markdown_checklist.extension
docmark: <
display: public
         protected
         private

{!README-PENF.md!}
