title: build.sh

Below is the build script used to build JSON-Fortran using
[FoBiS.py](https://github.com/szaghi/FoBiS).

```bash
{!build.sh!}
```
