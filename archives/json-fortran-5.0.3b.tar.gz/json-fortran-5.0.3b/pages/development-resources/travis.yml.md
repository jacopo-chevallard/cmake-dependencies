title: .travis.yml

This is the
[Travis-CI](https://travis-ci.org/jacobwilliams/json-fortran) script
used to perform continuous integration testing for JSON-Fortran, and
trigger automatic documentation deployment.

```yml
{!.travis.yml!}
```
