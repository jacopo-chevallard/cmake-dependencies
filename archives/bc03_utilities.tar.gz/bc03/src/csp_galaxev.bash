#! /bin/sh

# Script csp_galaxev.sh
source $bc03/.bc_bash
$bc03/csp_galaxev
source ./bc03.rm
\rm bc03.rm
