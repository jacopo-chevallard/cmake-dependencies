#! /bin/sh

# Script mm_evolution.sh
source $bc03/.bc_bash
$bc03/mm_evolution
