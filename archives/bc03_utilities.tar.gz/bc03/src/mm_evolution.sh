#! /bin/sh

# Script mm_evolution.sh
source $bc03/.bc_cshrc
$bc03/mm_evolution
