#! /bin/sh

# Script cm_evolution.sh
source $bc03/.bc_cshrc
$bc03/cm_evolution
