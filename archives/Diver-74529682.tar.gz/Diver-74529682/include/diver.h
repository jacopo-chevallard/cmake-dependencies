// C prototype of the main run_de function for Diver.
extern void cdiver(double (*)(double[], const int, int*, bool*, const bool, void**), int, const double[], const double[], 
		   const char[], int, int, const int[], bool, const int, const int, int, int, const double[], double, 
		   double, bool, bool, int, bool, bool, double, int, bool, bool, double(*)(const double[], const int, void**), 
		   double, double, int, bool, bool, int, int, double, void**, int);
