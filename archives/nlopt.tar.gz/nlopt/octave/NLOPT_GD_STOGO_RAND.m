% NLOPT_GD_STOGO_RAND: StoGO with randomized search (global, derivative-based)
%
% See nlopt_minimize for more information.
function val = NLOPT_GD_STOGO_RAND
  val = 9;
